var searchData=
[
  ['set_5fstream_5fmode_0',['SET_STREAM_MODE',['../group__m__i8042.html#gaabf49b4a4d8ad72d202c8a7197058e35',1,'m_i8042.h']]],
  ['shoot_1',['shoot',['../group__game.html#ga55f7aa20e5f30893153c740360628be7',1,'shoot():&#160;game.c'],['../group__game.html#ga55f7aa20e5f30893153c740360628be7',1,'shoot():&#160;game.c']]],
  ['shortestpath_2',['shortestPath',['../group__game.html#gaa307105f28d94b8d7efe74a8b14788f5',1,'shortestPath(int x1, int y1, int x2, int y2):&#160;game.c'],['../group__game.html#gaa307105f28d94b8d7efe74a8b14788f5',1,'shortestPath(int x1, int y1, int x2, int y2):&#160;game.c']]],
  ['speaker_5fctrl_3',['SPEAKER_CTRL',['../group__i8254.html#ga51b3a5e3d4811ca063fe25e35560ab40',1,'i8254.h']]],
  ['sprites_4',['sprites',['../group__sprites.html',1,'']]]
];
