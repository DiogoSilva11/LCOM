var searchData=
[
  ['leave_0',['leave',['../group__controller.html#ga5660953c43c447e3e57c44f7eacf432e',1,'leave():&#160;controller.c'],['../group__controller.html#ga5660953c43c447e3e57c44f7eacf432e',1,'leave():&#160;controller.c']]],
  ['loadgame_1',['loadGame',['../group__game.html#gaf4029921a2d0b9b268f79e81a47763b9',1,'loadGame():&#160;game.c'],['../group__game.html#gaf4029921a2d0b9b268f79e81a47763b9',1,'loadGame():&#160;game.c']]]
];
