var indexSectionsWithContent =
{
  0: "abcdefghiklmnrstvw",
  1: "bcfhr",
  2: "bcdgiklmsv",
  3: "bcgikmstv"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "functions",
  3: "groups"
};

var indexSectionLabels =
{
  0: "All",
  1: "Data Structures",
  2: "Functions",
  3: "Modules"
};

