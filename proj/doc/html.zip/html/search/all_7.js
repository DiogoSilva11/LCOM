var searchData=
[
  ['hero_0',['Hero',['../struct_hero.html',1,'']]],
  ['hero_5fx_5fspeed_1',['HERO_X_SPEED',['../group__info.html#ga87d2c9ef98aa686a86a430fc14631251',1,'info.h']]],
  ['hero_5fy_5fspeed_2',['HERO_Y_SPEED',['../group__info.html#gaa6eb222c4903ae0b022e30f0474a4700',1,'info.h']]]
];
