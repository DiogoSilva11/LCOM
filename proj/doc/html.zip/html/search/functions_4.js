var searchData=
[
  ['init_0',['init',['../group__controller.html#ga6611da0eaaaa020ce5748914abff7828',1,'init():&#160;controller.c'],['../group__controller.html#ga6611da0eaaaa020ce5748914abff7828',1,'init():&#160;controller.c']]]
];
