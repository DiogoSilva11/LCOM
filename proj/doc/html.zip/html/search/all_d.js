var searchData=
[
  ['read_5fcmd_5fbyte_0',['READ_CMD_BYTE',['../group__m__i8042.html#ga3edb96ff4ed65c98f514852bcdd4f944',1,'m_i8042.h']]],
  ['robot_1',['Robot',['../struct_robot.html',1,'']]],
  ['robot_5fx_5fspeed_2',['ROBOT_X_SPEED',['../group__info.html#gae7d623dab8f9d1af8d33f09ba6ebc69f',1,'info.h']]],
  ['robot_5fy_5fspeed_3',['ROBOT_Y_SPEED',['../group__info.html#ga0756a85f156e55865c646eee3d854700',1,'info.h']]]
];
