var searchData=
[
  ['gameplay_0',['gameplay',['../group__game.html#gaccc0035ada283ea1150fbf31dd912e51',1,'gameplay():&#160;game.c'],['../group__game.html#gaccc0035ada283ea1150fbf31dd912e51',1,'gameplay():&#160;game.c']]],
  ['get_5fhres_1',['get_hres',['../group__vbe.html#ga96831d611df1b6f4402dec1da8eaaef5',1,'get_hres():&#160;vbe.c'],['../group__vbe.html#ga96831d611df1b6f4402dec1da8eaaef5',1,'get_hres():&#160;vbe.c']]],
  ['get_5fkey_2',['get_key',['../group__kbd.html#gacc0273d7f541382cc677c6397ba623b4',1,'get_key():&#160;kbd.c'],['../group__kbd.html#gacc0273d7f541382cc677c6397ba623b4',1,'get_key():&#160;kbd.c']]],
  ['get_5fvres_3',['get_vres',['../group__vbe.html#gadbb976e8111bdebbf31503894844e592',1,'get_vres():&#160;vbe.c'],['../group__vbe.html#gadbb976e8111bdebbf31503894844e592',1,'get_vres():&#160;vbe.c']]],
  ['getpixelx_4',['getPixelX',['../group__game.html#ga478b0de75252b629e03a0d2f5908fbd3',1,'getPixelX(int logX):&#160;game.c'],['../group__game.html#ga478b0de75252b629e03a0d2f5908fbd3',1,'getPixelX(int logX):&#160;game.c']]],
  ['getpixely_5',['getPixelY',['../group__game.html#ga90d97583a767aafbe03b4bd9efc7ac58',1,'getPixelY(int logY):&#160;game.c'],['../group__game.html#ga90d97583a767aafbe03b4bd9efc7ac58',1,'getPixelY(int logY):&#160;game.c']]]
];
