var searchData=
[
  ['canheromove_0',['canHeroMove',['../group__game.html#ga550d7ad57789978872d4828ded7f5259',1,'canHeroMove(uint16_t newX, uint16_t newY):&#160;game.c'],['../group__game.html#ga550d7ad57789978872d4828ded7f5259',1,'canHeroMove(uint16_t newX, uint16_t newY):&#160;game.c']]],
  ['canrobotmove_1',['canRobotMove',['../group__game.html#gaa73b620bdae2516d5a314745fa60bc00',1,'canRobotMove(int id, uint16_t newX, uint16_t newY):&#160;game.c'],['../group__game.html#gaa73b620bdae2516d5a314745fa60bc00',1,'canRobotMove(int id, uint16_t newX, uint16_t newY):&#160;game.c']]],
  ['checkcollision_2',['checkCollision',['../group__game.html#ga03068e2aff356769b491551069068fe8',1,'checkCollision(int x1, int y1, int w1, int h1, int x2, int y2, int w2, int h2):&#160;game.c'],['../group__game.html#ga03068e2aff356769b491551069068fe8',1,'checkCollision(int x1, int y1, int w1, int h1, int x2, int y2, int w2, int h2):&#160;game.c']]],
  ['checkhit_3',['checkHit',['../group__game.html#ga528836c3d8b06eae9b01228559af211e',1,'checkHit(uint16_t newX, uint16_t newY):&#160;game.c'],['../group__game.html#ga528836c3d8b06eae9b01228559af211e',1,'checkHit(uint16_t newX, uint16_t newY):&#160;game.c']]],
  ['crosshaircenterx_4',['crosshairCenterX',['../group__game.html#ga41a3ebfab1594802cbab666c168c10d2',1,'crosshairCenterX():&#160;game.c'],['../group__game.html#ga41a3ebfab1594802cbab666c168c10d2',1,'crosshairCenterX():&#160;game.c']]],
  ['crosshaircentery_5',['crosshairCenterY',['../group__game.html#gae477a4a47b10e8d87a068705d72dcb40',1,'crosshairCenterY():&#160;game.c'],['../group__game.html#gae477a4a47b10e8d87a068705d72dcb40',1,'crosshairCenterY():&#160;game.c']]]
];
