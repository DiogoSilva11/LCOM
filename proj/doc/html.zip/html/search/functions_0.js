var searchData=
[
  ['bulletdirection_0',['bulletDirection',['../group__game.html#gaa6f34964f7bd42459a335dbe1f143671',1,'bulletDirection():&#160;game.c'],['../group__game.html#gaa6f34964f7bd42459a335dbe1f143671',1,'bulletDirection():&#160;game.c']]],
  ['bulletreset_1',['bulletReset',['../group__game.html#gaa2f6a3d662c47f326b3ee92918d0ac29',1,'bulletReset():&#160;game.c'],['../group__game.html#gaa2f6a3d662c47f326b3ee92918d0ac29',1,'bulletReset():&#160;game.c']]],
  ['bulletstore_2',['bulletStore',['../group__game.html#gaa3112556fa20aae4b8957136f68b5d62',1,'bulletStore():&#160;game.c'],['../group__game.html#gaa3112556fa20aae4b8957136f68b5d62',1,'bulletStore():&#160;game.c']]],
  ['bullettravel_3',['bulletTravel',['../group__game.html#ga42c263b67e0de29b07476c10ea7be4b2',1,'bulletTravel():&#160;game.c'],['../group__game.html#ga42c263b67e0de29b07476c10ea7be4b2',1,'bulletTravel():&#160;game.c']]],
  ['bytes_5fper_5fpixel_4',['bytes_per_pixel',['../group__vbe.html#gaac1597a72e55f391bfb1569d215feaab',1,'bytes_per_pixel():&#160;vbe.c'],['../group__vbe.html#gaac1597a72e55f391bfb1569d215feaab',1,'bytes_per_pixel():&#160;vbe.c']]]
];
