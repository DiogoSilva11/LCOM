var searchData=
[
  ['arena_5fheight_0',['ARENA_HEIGHT',['../group__info.html#ga74c65f2cf6e5f55b98e9884867db6d2e',1,'info.h']]],
  ['arena_5fwidth_1',['ARENA_WIDTH',['../group__info.html#ga0264098c1e94fd9923fc75558e16baf9',1,'info.h']]],
  ['arena_5fx_5forigin_2',['ARENA_X_ORIGIN',['../group__info.html#ga2e4e69f01a9723fab8cf3b294d12594e',1,'info.h']]],
  ['arena_5fy_5forigin_3',['ARENA_Y_ORIGIN',['../group__info.html#ga6e9bbd52a61770960830328dde50e626',1,'info.h']]]
];
