var searchData=
[
  ['num_5ffences_0',['NUM_FENCES',['../group__info.html#ga8dd6c08ad76872a42dfab2d4980b8f4e',1,'info.h']]],
  ['num_5frobots_1',['NUM_ROBOTS',['../group__info.html#ga71889ba3881d704ffca0ab1a73a50215',1,'info.h']]]
];
