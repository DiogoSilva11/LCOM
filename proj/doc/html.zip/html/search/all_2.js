var searchData=
[
  ['canheromove_0',['canHeroMove',['../group__game.html#ga550d7ad57789978872d4828ded7f5259',1,'canHeroMove(uint16_t newX, uint16_t newY):&#160;game.c'],['../group__game.html#ga550d7ad57789978872d4828ded7f5259',1,'canHeroMove(uint16_t newX, uint16_t newY):&#160;game.c']]],
  ['canrobotmove_1',['canRobotMove',['../group__game.html#gaa73b620bdae2516d5a314745fa60bc00',1,'canRobotMove(int id, uint16_t newX, uint16_t newY):&#160;game.c'],['../group__game.html#gaa73b620bdae2516d5a314745fa60bc00',1,'canRobotMove(int id, uint16_t newX, uint16_t newY):&#160;game.c']]],
  ['check_5fmouse_5finterface_2',['CHECK_MOUSE_INTERFACE',['../group__m__i8042.html#ga8b6ad5cab3f7946154fe5457b0b24ca8',1,'m_i8042.h']]],
  ['checkcollision_3',['checkCollision',['../group__game.html#ga03068e2aff356769b491551069068fe8',1,'checkCollision(int x1, int y1, int w1, int h1, int x2, int y2, int w2, int h2):&#160;game.c'],['../group__game.html#ga03068e2aff356769b491551069068fe8',1,'checkCollision(int x1, int y1, int w1, int h1, int x2, int y2, int w2, int h2):&#160;game.c']]],
  ['checkhit_4',['checkHit',['../group__game.html#ga528836c3d8b06eae9b01228559af211e',1,'checkHit(uint16_t newX, uint16_t newY):&#160;game.c'],['../group__game.html#ga528836c3d8b06eae9b01228559af211e',1,'checkHit(uint16_t newX, uint16_t newY):&#160;game.c']]],
  ['console_5fheight_5',['CONSOLE_HEIGHT',['../group__info.html#ga157ee137a3acabff3d7612bff73b448b',1,'info.h']]],
  ['console_5fwidth_6',['CONSOLE_WIDTH',['../group__info.html#gac8a565248bf80a622adcf61f4fe6dbc3',1,'info.h']]],
  ['controller_7',['controller',['../group__controller.html',1,'']]],
  ['crosshair_8',['Crosshair',['../struct_crosshair.html',1,'']]],
  ['crosshaircenterx_9',['crosshairCenterX',['../group__game.html#ga41a3ebfab1594802cbab666c168c10d2',1,'crosshairCenterX():&#160;game.c'],['../group__game.html#ga41a3ebfab1594802cbab666c168c10d2',1,'crosshairCenterX():&#160;game.c']]],
  ['crosshaircentery_10',['crosshairCenterY',['../group__game.html#gae477a4a47b10e8d87a068705d72dcb40',1,'crosshairCenterY():&#160;game.c'],['../group__game.html#gae477a4a47b10e8d87a068705d72dcb40',1,'crosshairCenterY():&#160;game.c']]]
];
