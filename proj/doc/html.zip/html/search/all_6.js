var searchData=
[
  ['game_0',['game',['../group__game.html',1,'']]],
  ['game_5ffps_1',['GAME_FPS',['../group__info.html#ga63a780eb9590cbea188494a74c8eb79e',1,'info.h']]],
  ['game_5fmode_2',['GAME_MODE',['../group__info.html#ga0e6eed752f69ec92baec7d38a6ff3f04',1,'info.h']]],
  ['gameplay_3',['gameplay',['../group__game.html#gaccc0035ada283ea1150fbf31dd912e51',1,'gameplay():&#160;game.c'],['../group__game.html#gaccc0035ada283ea1150fbf31dd912e51',1,'gameplay():&#160;game.c']]],
  ['get_5fhres_4',['get_hres',['../group__vbe.html#ga96831d611df1b6f4402dec1da8eaaef5',1,'get_hres():&#160;vbe.c'],['../group__vbe.html#ga96831d611df1b6f4402dec1da8eaaef5',1,'get_hres():&#160;vbe.c']]],
  ['get_5fkey_5',['get_key',['../group__kbd.html#gacc0273d7f541382cc677c6397ba623b4',1,'get_key():&#160;kbd.c'],['../group__kbd.html#gacc0273d7f541382cc677c6397ba623b4',1,'get_key():&#160;kbd.c']]],
  ['get_5fvres_6',['get_vres',['../group__vbe.html#gadbb976e8111bdebbf31503894844e592',1,'get_vres():&#160;vbe.c'],['../group__vbe.html#gadbb976e8111bdebbf31503894844e592',1,'get_vres():&#160;vbe.c']]],
  ['getpixelx_7',['getPixelX',['../group__game.html#ga478b0de75252b629e03a0d2f5908fbd3',1,'getPixelX(int logX):&#160;game.c'],['../group__game.html#ga478b0de75252b629e03a0d2f5908fbd3',1,'getPixelX(int logX):&#160;game.c']]],
  ['getpixely_8',['getPixelY',['../group__game.html#ga90d97583a767aafbe03b4bd9efc7ac58',1,'getPixelY(int logY):&#160;game.c'],['../group__game.html#ga90d97583a767aafbe03b4bd9efc7ac58',1,'getPixelY(int logY):&#160;game.c']]]
];
