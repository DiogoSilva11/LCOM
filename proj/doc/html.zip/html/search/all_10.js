var searchData=
[
  ['validgame_0',['validGame',['../group__game.html#ga8a3599fbcbfcf0a2f2357d7a617550ac',1,'validGame():&#160;game.c'],['../group__game.html#ga8a3599fbcbfcf0a2f2357d7a617550ac',1,'validGame():&#160;game.c']]],
  ['vbe_1',['vbe',['../group__vbe.html',1,'']]],
  ['vbe_5ffunc_5fcall_2',['VBE_FUNC_CALL',['../group__bios.html#ga919813aaa650de9b3434b9bf1970ed5c',1,'bios.h']]],
  ['vbe_5ffunc_5ffail_3',['VBE_FUNC_FAIL',['../group__bios.html#gac0799fa6d233f113fb31ece5c47dc5c8',1,'bios.h']]],
  ['vbe_5ffunc_5fhw_4',['VBE_FUNC_HW',['../group__bios.html#ga48dc977c617273138ddbd1d561203626',1,'bios.h']]],
  ['vbe_5ffunc_5finv_5',['VBE_FUNC_INV',['../group__bios.html#ga73c2351a1134cbc27d69fcff7235f163',1,'bios.h']]],
  ['vbe_5ffunc_5fok_6',['VBE_FUNC_OK',['../group__bios.html#gacf43e5c9535103ab7cdb9ec58f24139b',1,'bios.h']]],
  ['vbe_5ffunc_5fsup_7',['VBE_FUNC_SUP',['../group__bios.html#ga30e52e7aff947a78b13091e2563d437f',1,'bios.h']]],
  ['vbe_5flinear_5fbuf_8',['VBE_LINEAR_BUF',['../group__bios.html#ga4f973c2c166ca409c8dc18e0810de106',1,'bios.h']]],
  ['vbe_5fmode_5finfo_9',['VBE_MODE_INFO',['../group__bios.html#ga2ecbf8f92f9322fedec91461747c4843',1,'bios.h']]],
  ['vbe_5fset_5fmode_10',['VBE_SET_MODE',['../group__bios.html#ga02477c4996ff058aee590b54f2146eb5',1,'bios.h']]],
  ['vg_5fclear_5fscreen_11',['vg_clear_screen',['../group__vbe.html#ga5d8853f182ab463c0d667a1c802a3713',1,'vg_clear_screen():&#160;vbe.c'],['../group__vbe.html#ga5d8853f182ab463c0d667a1c802a3713',1,'vg_clear_screen():&#160;vbe.c']]],
  ['vg_5fdraw_5fcontent_12',['vg_draw_content',['../group__vbe.html#gac305e1409155c669200217cc8a7aefce',1,'vg_draw_content():&#160;vbe.c'],['../group__vbe.html#gac305e1409155c669200217cc8a7aefce',1,'vg_draw_content():&#160;vbe.c']]],
  ['vg_5fdraw_5felement_13',['vg_draw_element',['../group__vbe.html#ga4ccb0c4ec0db3c700b6d20b02175f534',1,'vg_draw_element(xpm_row_t *pixmap, uint16_t x, uint16_t y):&#160;vbe.c'],['../group__vbe.html#ga4ccb0c4ec0db3c700b6d20b02175f534',1,'vg_draw_element(xpm_row_t *pixmap, uint16_t x, uint16_t y):&#160;vbe.c']]],
  ['vg_5fdraw_5fsprite_14',['vg_draw_sprite',['../group__vbe.html#ga7aacee3dbbba922b03e8d29d511d6897',1,'vg_draw_sprite(uint8_t *sprite, uint16_t x, uint16_t y, uint16_t width, uint16_t height):&#160;vbe.c'],['../group__vbe.html#ga7aacee3dbbba922b03e8d29d511d6897',1,'vg_draw_sprite(uint8_t *sprite, uint16_t x, uint16_t y, uint16_t width, uint16_t height):&#160;vbe.c']]],
  ['vg_5fgenerate_5fpixel_15',['vg_generate_pixel',['../group__vbe.html#ga99cb2ed48beffe1117bab7d4ebc1eb57',1,'vg_generate_pixel(uint16_t x, uint16_t y, uint32_t color):&#160;vbe.c'],['../group__vbe.html#ga99cb2ed48beffe1117bab7d4ebc1eb57',1,'vg_generate_pixel(uint16_t x, uint16_t y, uint32_t color):&#160;vbe.c']]],
  ['vg_5fread_5fpixmap_16',['vg_read_pixmap',['../group__vbe.html#ga2c6963e43720b5e7a395acaebd5cdcb9',1,'vg_read_pixmap(xpm_row_t *pixmap, uint16_t *width, uint16_t *height):&#160;vbe.c'],['../group__vbe.html#ga2c6963e43720b5e7a395acaebd5cdcb9',1,'vg_read_pixmap(xpm_row_t *pixmap, uint16_t *width, uint16_t *height):&#160;vbe.c']]]
];
