var searchData=
[
  ['hero_0',['Hero',['../struct_hero.html',1,'']]]
];
