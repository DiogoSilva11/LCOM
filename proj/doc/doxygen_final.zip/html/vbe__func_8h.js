var vbe__func_8h =
[
    [ "bytes_per_pixel", "vbe__func_8h.html#aac1597a72e55f391bfb1569d215feaab", null ],
    [ "get_hres", "vbe__func_8h.html#a96831d611df1b6f4402dec1da8eaaef5", null ],
    [ "get_vres", "vbe__func_8h.html#adbb976e8111bdebbf31503894844e592", null ],
    [ "map_memory", "vbe__func_8h.html#af1bf9e7f07f92f3f1561df4630ce33d1", null ],
    [ "vg_clear_screen", "vbe__func_8h.html#a5d8853f182ab463c0d667a1c802a3713", null ],
    [ "vg_draw_content", "vbe__func_8h.html#ac305e1409155c669200217cc8a7aefce", null ],
    [ "vg_draw_element", "vbe__func_8h.html#a4ccb0c4ec0db3c700b6d20b02175f534", null ],
    [ "vg_draw_sprite", "vbe__func_8h.html#a7aacee3dbbba922b03e8d29d511d6897", null ],
    [ "vg_generate_pixel", "vbe__func_8h.html#a99cb2ed48beffe1117bab7d4ebc1eb57", null ],
    [ "vg_read_pixmap", "vbe__func_8h.html#a0c16850c0cf73b1e331af7d5f189d30a", null ]
];