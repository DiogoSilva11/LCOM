var searchData=
[
  ['clrdepth_376',['clrdepth',['../vbe_8c.html#a832eacefacc19cebd5f39e42dccc12af',1,'vbe.c']]],
  ['counter_377',['counter',['../mouse_8c.html#a617a47c70795bcff659815ad0efd2266',1,'mouse.c']]],
  ['crosshair_378',['crosshair',['../game_8c.html#a5f4ca3b28f7e431f02f63cda6f1337bd',1,'game.c']]],
  ['crosshair_5fsprite_379',['crosshair_sprite',['../group__xpm.html#ga5a8bab6f75c6330bc3451f24514c552d',1,'sprites.h']]]
];
