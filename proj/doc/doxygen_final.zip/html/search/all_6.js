var searchData=
[
  ['game_2ec_53',['game.c',['../game_8c.html',1,'']]],
  ['game_2eh_54',['game.h',['../game_8h.html',1,'']]],
  ['game_5ffps_55',['GAME_FPS',['../info_8h.html#a63a780eb9590cbea188494a74c8eb79e',1,'info.h']]],
  ['game_5fmode_56',['GAME_MODE',['../info_8h.html#a0e6eed752f69ec92baec7d38a6ff3f04',1,'info.h']]],
  ['gameplay_57',['gameplay',['../game_8c.html#accc0035ada283ea1150fbf31dd912e51',1,'gameplay():&#160;game.c'],['../game_8h.html#accc0035ada283ea1150fbf31dd912e51',1,'gameplay():&#160;game.c']]],
  ['get_5fhres_58',['get_hres',['../vbe_8c.html#a96831d611df1b6f4402dec1da8eaaef5',1,'get_hres():&#160;vbe.c'],['../vbe__func_8h.html#a96831d611df1b6f4402dec1da8eaaef5',1,'get_hres():&#160;vbe.c']]],
  ['get_5fkey_59',['get_key',['../group__kbd.html#gacc0273d7f541382cc677c6397ba623b4',1,'get_key():&#160;kbd.c'],['../group__kbd.html#gacc0273d7f541382cc677c6397ba623b4',1,'get_key():&#160;kbd.c']]],
  ['get_5fvres_60',['get_vres',['../vbe_8c.html#adbb976e8111bdebbf31503894844e592',1,'get_vres():&#160;vbe.c'],['../vbe__func_8h.html#adbb976e8111bdebbf31503894844e592',1,'get_vres():&#160;vbe.c']]],
  ['getpixelx_61',['getPixelX',['../game_8c.html#a478b0de75252b629e03a0d2f5908fbd3',1,'getPixelX(int logX):&#160;game.c'],['../game_8h.html#a478b0de75252b629e03a0d2f5908fbd3',1,'getPixelX(int logX):&#160;game.c']]],
  ['getpixely_62',['getPixelY',['../game_8c.html#a90d97583a767aafbe03b4bd9efc7ac58',1,'getPixelY(int logY):&#160;game.c'],['../game_8h.html#a90d97583a767aafbe03b4bd9efc7ac58',1,'getPixelY(int logY):&#160;game.c']]],
  ['grey_63',['GREY',['../info_8h.html#adce122f566c88a1eceeb79a635afa964',1,'info.h']]]
];
