var searchData=
[
  ['console_5fheight_423',['CONSOLE_HEIGHT',['../info_8h.html#a157ee137a3acabff3d7612bff73b448b',1,'info.h']]],
  ['console_5fwidth_424',['CONSOLE_WIDTH',['../info_8h.html#ac8a565248bf80a622adcf61f4fe6dbc3',1,'info.h']]]
];
