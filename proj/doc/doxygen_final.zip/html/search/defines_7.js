var searchData=
[
  ['num_5ffences_439',['NUM_FENCES',['../info_8h.html#a8dd6c08ad76872a42dfab2d4980b8f4e',1,'info.h']]],
  ['num_5frobots_440',['NUM_ROBOTS',['../info_8h.html#a71889ba3881d704ffca0ab1a73a50215',1,'info.h']]]
];
