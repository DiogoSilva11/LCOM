var searchData=
[
  ['scancode_184',['scancode',['../group__kbd.html#ga01577ed8d3646775ae6a8e00d24c1d94',1,'kbd.h']]],
  ['set_5fstream_5fmode_185',['SET_STREAM_MODE',['../group__m__i8042.html#gaabf49b4a4d8ad72d202c8a7197058e35',1,'m_i8042.h']]],
  ['shoot_186',['shoot',['../game_8c.html#a55f7aa20e5f30893153c740360628be7',1,'shoot():&#160;game.c'],['../game_8h.html#a55f7aa20e5f30893153c740360628be7',1,'shoot():&#160;game.c']]],
  ['shortestpath_187',['shortestPath',['../game_8c.html#aa307105f28d94b8d7efe74a8b14788f5',1,'shortestPath(int x1, int y1, int x2, int y2):&#160;game.c'],['../game_8h.html#aa307105f28d94b8d7efe74a8b14788f5',1,'shortestPath(int x1, int y1, int x2, int y2):&#160;game.c']]],
  ['speaker_5fctrl_188',['SPEAKER_CTRL',['../group__i8254.html#ga51b3a5e3d4811ca063fe25e35560ab40',1,'i8254.h']]],
  ['sprites_2eh_189',['sprites.h',['../sprites_8h.html',1,'']]]
];
