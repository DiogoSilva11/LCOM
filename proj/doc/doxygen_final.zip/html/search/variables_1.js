var searchData=
[
  ['bullet_374',['bullet',['../game_8c.html#ab39d816814fe29da0500d9957f2628f6',1,'game.c']]],
  ['bullet_5fsprite_375',['bullet_sprite',['../group__xpm.html#gaedb14372b536a8f763851c28d634a388',1,'sprites.h']]]
];
