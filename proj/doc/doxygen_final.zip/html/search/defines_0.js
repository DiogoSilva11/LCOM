var searchData=
[
  ['arena_5fheight_415',['ARENA_HEIGHT',['../info_8h.html#a74c65f2cf6e5f55b98e9884867db6d2e',1,'info.h']]],
  ['arena_5fwidth_416',['ARENA_WIDTH',['../info_8h.html#a0264098c1e94fd9923fc75558e16baf9',1,'info.h']]],
  ['arena_5fx_5forigin_417',['ARENA_X_ORIGIN',['../info_8h.html#a2e4e69f01a9723fab8cf3b294d12594e',1,'info.h']]],
  ['arena_5fy_5forigin_418',['ARENA_Y_ORIGIN',['../info_8h.html#a6e9bbd52a61770960830328dde50e626',1,'info.h']]]
];
