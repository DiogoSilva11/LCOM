var searchData=
[
  ['robot_5fx_5fspeed_441',['ROBOT_X_SPEED',['../info_8h.html#ae7d623dab8f9d1af8d33f09ba6ebc69f',1,'info.h']]],
  ['robot_5fy_5fspeed_442',['ROBOT_Y_SPEED',['../info_8h.html#a0756a85f156e55865c646eee3d854700',1,'info.h']]]
];
