var searchData=
[
  ['game_5ffps_427',['GAME_FPS',['../info_8h.html#a63a780eb9590cbea188494a74c8eb79e',1,'info.h']]],
  ['game_5fmode_428',['GAME_MODE',['../info_8h.html#a0e6eed752f69ec92baec7d38a6ff3f04',1,'info.h']]],
  ['grey_429',['GREY',['../info_8h.html#adce122f566c88a1eceeb79a635afa964',1,'info.h']]]
];
