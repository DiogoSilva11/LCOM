var searchData=
[
  ['video_5fbuffer_396',['video_buffer',['../vbe_8c.html#a9dd702e63e63161a33a17df975310705',1,'vbe.c']]],
  ['video_5fmem_397',['video_mem',['../vbe_8c.html#a5077a1a703b40b073dc6b5c1129ab0a1',1,'vbe.c']]],
  ['vmi_5fp_398',['vmi_p',['../vbe_8c.html#a26081be7a771e5c611b33f15caaf831e',1,'vbe.c']]],
  ['vram_5fsize_399',['vram_size',['../vbe_8c.html#a17b12b87c65aaa04215d9bdb7e9e84dd',1,'vbe.c']]],
  ['vres_400',['vres',['../vbe_8c.html#a573eca15e5986d6dd7ae53b5dab582e2',1,'vbe.c']]]
];
