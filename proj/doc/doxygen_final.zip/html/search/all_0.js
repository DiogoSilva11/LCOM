var searchData=
[
  ['alive_0',['alive',['../structHero.html#aa638f6d83580dacb46d8e3e9358066b1',1,'Hero::alive()'],['../structRobot.html#a40baadb1b9c433367118014204714d41',1,'Robot::alive()']]],
  ['arena_5fheight_1',['ARENA_HEIGHT',['../info_8h.html#a74c65f2cf6e5f55b98e9884867db6d2e',1,'info.h']]],
  ['arena_5fwidth_2',['ARENA_WIDTH',['../info_8h.html#a0264098c1e94fd9923fc75558e16baf9',1,'info.h']]],
  ['arena_5fx_5forigin_3',['ARENA_X_ORIGIN',['../info_8h.html#a2e4e69f01a9723fab8cf3b294d12594e',1,'info.h']]],
  ['arena_5fy_5forigin_4',['ARENA_Y_ORIGIN',['../info_8h.html#a6e9bbd52a61770960830328dde50e626',1,'info.h']]]
];
