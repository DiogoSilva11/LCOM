var searchData=
[
  ['canheromove_294',['canHeroMove',['../game_8c.html#a550d7ad57789978872d4828ded7f5259',1,'canHeroMove(uint16_t newX, uint16_t newY):&#160;game.c'],['../game_8h.html#a550d7ad57789978872d4828ded7f5259',1,'canHeroMove(uint16_t newX, uint16_t newY):&#160;game.c']]],
  ['canrobotmove_295',['canRobotMove',['../game_8c.html#aa73b620bdae2516d5a314745fa60bc00',1,'canRobotMove(int id, uint16_t newX, uint16_t newY):&#160;game.c'],['../game_8h.html#aa73b620bdae2516d5a314745fa60bc00',1,'canRobotMove(int id, uint16_t newX, uint16_t newY):&#160;game.c']]],
  ['checkcollision_296',['checkCollision',['../game_8c.html#a03068e2aff356769b491551069068fe8',1,'checkCollision(int x1, int y1, int w1, int h1, int x2, int y2, int w2, int h2):&#160;game.c'],['../game_8h.html#a03068e2aff356769b491551069068fe8',1,'checkCollision(int x1, int y1, int w1, int h1, int x2, int y2, int w2, int h2):&#160;game.c']]],
  ['checkhit_297',['checkHit',['../game_8c.html#a528836c3d8b06eae9b01228559af211e',1,'checkHit(uint16_t newX, uint16_t newY):&#160;game.c'],['../game_8h.html#a528836c3d8b06eae9b01228559af211e',1,'checkHit(uint16_t newX, uint16_t newY):&#160;game.c']]],
  ['crosshaircenterx_298',['crosshairCenterX',['../game_8c.html#a41a3ebfab1594802cbab666c168c10d2',1,'crosshairCenterX():&#160;game.c'],['../game_8h.html#a41a3ebfab1594802cbab666c168c10d2',1,'crosshairCenterX():&#160;game.c']]],
  ['crosshaircentery_299',['crosshairCenterY',['../game_8c.html#ae477a4a47b10e8d87a068705d72dcb40',1,'crosshairCenterY():&#160;game.c'],['../game_8h.html#ae477a4a47b10e8d87a068705d72dcb40',1,'crosshairCenterY():&#160;game.c']]]
];
