var searchData=
[
  ['mouse_5firq_5fset_390',['mouse_irq_set',['../controller_8c.html#a9492cf9c0db01b22708557dfed5fef2b',1,'mouse_irq_set():&#160;controller.c'],['../info_8h.html#a9492cf9c0db01b22708557dfed5fef2b',1,'mouse_irq_set():&#160;controller.c']]]
];
