var searchData=
[
  ['dead_5frobot_5fsprite_380',['dead_robot_sprite',['../group__xpm.html#ga0394512e76820d88136bd498d8e1fe95',1,'sprites.h']]]
];
