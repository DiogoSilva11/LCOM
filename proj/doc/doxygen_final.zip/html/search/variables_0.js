var searchData=
[
  ['alive_373',['alive',['../structHero.html#aa638f6d83580dacb46d8e3e9358066b1',1,'Hero::alive()'],['../structRobot.html#a40baadb1b9c433367118014204714d41',1,'Robot::alive()']]]
];
