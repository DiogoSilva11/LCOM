var searchData=
[
  ['shoot_352',['shoot',['../game_8c.html#a55f7aa20e5f30893153c740360628be7',1,'shoot():&#160;game.c'],['../game_8h.html#a55f7aa20e5f30893153c740360628be7',1,'shoot():&#160;game.c']]],
  ['shortestpath_353',['shortestPath',['../game_8c.html#aa307105f28d94b8d7efe74a8b14788f5',1,'shortestPath(int x1, int y1, int x2, int y2):&#160;game.c'],['../game_8h.html#aa307105f28d94b8d7efe74a8b14788f5',1,'shortestPath(int x1, int y1, int x2, int y2):&#160;game.c']]]
];
