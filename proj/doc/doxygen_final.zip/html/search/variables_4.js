var searchData=
[
  ['fence_5fsprite_381',['fence_sprite',['../group__xpm.html#gac3bca7ac2010a0513d4b3ea7f8cc54a2',1,'sprites.h']]],
  ['fences_382',['fences',['../game_8c.html#aa83247fcc8f51e2477469aee79f5af70',1,'game.c']]]
];
