var searchData=
[
  ['leave_327',['leave',['../controller_8c.html#a5660953c43c447e3e57c44f7eacf432e',1,'leave():&#160;controller.c'],['../controller_8h.html#a5660953c43c447e3e57c44f7eacf432e',1,'leave():&#160;controller.c']]],
  ['loadgame_328',['loadGame',['../game_8c.html#af4029921a2d0b9b268f79e81a47763b9',1,'loadGame():&#160;game.c'],['../game_8h.html#af4029921a2d0b9b268f79e81a47763b9',1,'loadGame():&#160;game.c']]]
];
