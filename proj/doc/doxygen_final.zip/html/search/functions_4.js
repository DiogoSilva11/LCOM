var searchData=
[
  ['init_313',['init',['../controller_8c.html#a6611da0eaaaa020ce5748914abff7828',1,'init():&#160;controller.c'],['../controller_8h.html#a6611da0eaaaa020ce5748914abff7828',1,'init():&#160;controller.c']]]
];
