var searchData=
[
  ['bulletreset_290',['bulletReset',['../game_8c.html#aa2f6a3d662c47f326b3ee92918d0ac29',1,'bulletReset():&#160;game.c'],['../game_8h.html#aa2f6a3d662c47f326b3ee92918d0ac29',1,'bulletReset():&#160;game.c']]],
  ['bulletstore_291',['bulletStore',['../game_8c.html#aa3112556fa20aae4b8957136f68b5d62',1,'bulletStore():&#160;game.c'],['../game_8h.html#aa3112556fa20aae4b8957136f68b5d62',1,'bulletStore():&#160;game.c']]],
  ['bullettravel_292',['bulletTravel',['../game_8c.html#a42c263b67e0de29b07476c10ea7be4b2',1,'bulletTravel():&#160;game.c'],['../game_8h.html#a42c263b67e0de29b07476c10ea7be4b2',1,'bulletTravel():&#160;game.c']]],
  ['bytes_5fper_5fpixel_293',['bytes_per_pixel',['../vbe_8c.html#aac1597a72e55f391bfb1569d215feaab',1,'bytes_per_pixel():&#160;vbe.c'],['../vbe__func_8h.html#aac1597a72e55f391bfb1569d215feaab',1,'bytes_per_pixel():&#160;vbe.c']]]
];
