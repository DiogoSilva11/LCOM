var searchData=
[
  ['hero_5fx_5fspeed_430',['HERO_X_SPEED',['../info_8h.html#a87d2c9ef98aa686a86a430fc14631251',1,'info.h']]],
  ['hero_5fy_5fspeed_431',['HERO_Y_SPEED',['../info_8h.html#aa6eb222c4903ae0b022e30f0474a4700',1,'info.h']]]
];
