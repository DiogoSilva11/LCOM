var searchData=
[
  ['canheromove_18',['canHeroMove',['../game_8c.html#a550d7ad57789978872d4828ded7f5259',1,'canHeroMove(uint16_t newX, uint16_t newY):&#160;game.c'],['../game_8h.html#a550d7ad57789978872d4828ded7f5259',1,'canHeroMove(uint16_t newX, uint16_t newY):&#160;game.c']]],
  ['canrobotmove_19',['canRobotMove',['../game_8c.html#aa73b620bdae2516d5a314745fa60bc00',1,'canRobotMove(int id, uint16_t newX, uint16_t newY):&#160;game.c'],['../game_8h.html#aa73b620bdae2516d5a314745fa60bc00',1,'canRobotMove(int id, uint16_t newX, uint16_t newY):&#160;game.c']]],
  ['check_5fmouse_5finterface_20',['CHECK_MOUSE_INTERFACE',['../group__m__i8042.html#ga8b6ad5cab3f7946154fe5457b0b24ca8',1,'m_i8042.h']]],
  ['checkcollision_21',['checkCollision',['../game_8c.html#a03068e2aff356769b491551069068fe8',1,'checkCollision(int x1, int y1, int w1, int h1, int x2, int y2, int w2, int h2):&#160;game.c'],['../game_8h.html#a03068e2aff356769b491551069068fe8',1,'checkCollision(int x1, int y1, int w1, int h1, int x2, int y2, int w2, int h2):&#160;game.c']]],
  ['checkhit_22',['checkHit',['../game_8c.html#a528836c3d8b06eae9b01228559af211e',1,'checkHit(uint16_t newX, uint16_t newY):&#160;game.c'],['../game_8h.html#a528836c3d8b06eae9b01228559af211e',1,'checkHit(uint16_t newX, uint16_t newY):&#160;game.c']]],
  ['clrdepth_23',['clrdepth',['../vbe_8c.html#a832eacefacc19cebd5f39e42dccc12af',1,'vbe.c']]],
  ['console_5fheight_24',['CONSOLE_HEIGHT',['../info_8h.html#a157ee137a3acabff3d7612bff73b448b',1,'info.h']]],
  ['console_5fwidth_25',['CONSOLE_WIDTH',['../info_8h.html#ac8a565248bf80a622adcf61f4fe6dbc3',1,'info.h']]],
  ['controller_2ec_26',['controller.c',['../controller_8c.html',1,'']]],
  ['controller_2eh_27',['controller.h',['../controller_8h.html',1,'']]],
  ['counter_28',['counter',['../mouse_8c.html#a617a47c70795bcff659815ad0efd2266',1,'mouse.c']]],
  ['crosshair_29',['Crosshair',['../structCrosshair.html',1,'Crosshair'],['../game_8c.html#a5f4ca3b28f7e431f02f63cda6f1337bd',1,'crosshair():&#160;game.c']]],
  ['crosshair_5fsprite_30',['crosshair_sprite',['../group__xpm.html#ga5a8bab6f75c6330bc3451f24514c552d',1,'sprites.h']]],
  ['crosshaircenterx_31',['crosshairCenterX',['../game_8c.html#a41a3ebfab1594802cbab666c168c10d2',1,'crosshairCenterX():&#160;game.c'],['../game_8h.html#a41a3ebfab1594802cbab666c168c10d2',1,'crosshairCenterX():&#160;game.c']]],
  ['crosshaircentery_32',['crosshairCenterY',['../game_8c.html#ae477a4a47b10e8d87a068705d72dcb40',1,'crosshairCenterY():&#160;game.c'],['../game_8h.html#ae477a4a47b10e8d87a068705d72dcb40',1,'crosshairCenterY():&#160;game.c']]]
];
