var searchData=
[
  ['robot_5fsprite_392',['robot_sprite',['../group__xpm.html#gad7444f5b4e7d8c23e2b95be18f28fde4',1,'sprites.h']]],
  ['robots_393',['robots',['../game_8c.html#ab53038d6d845a322f400e2a1e5329de9',1,'game.c']]]
];
