var searchData=
[
  ['validgame_363',['validGame',['../game_8c.html#a8a3599fbcbfcf0a2f2357d7a617550ac',1,'validGame():&#160;game.c'],['../game_8h.html#a8a3599fbcbfcf0a2f2357d7a617550ac',1,'validGame():&#160;game.c']]],
  ['vg_5fclear_5fscreen_364',['vg_clear_screen',['../vbe_8c.html#a5d8853f182ab463c0d667a1c802a3713',1,'vg_clear_screen():&#160;vbe.c'],['../vbe__func_8h.html#a5d8853f182ab463c0d667a1c802a3713',1,'vg_clear_screen():&#160;vbe.c']]],
  ['vg_5fdraw_5fcontent_365',['vg_draw_content',['../vbe_8c.html#ac305e1409155c669200217cc8a7aefce',1,'vg_draw_content():&#160;vbe.c'],['../vbe__func_8h.html#ac305e1409155c669200217cc8a7aefce',1,'vg_draw_content():&#160;vbe.c']]],
  ['vg_5fdraw_5felement_366',['vg_draw_element',['../vbe_8c.html#a4ccb0c4ec0db3c700b6d20b02175f534',1,'vg_draw_element(xpm_row_t *pixmap, uint16_t x, uint16_t y):&#160;vbe.c'],['../vbe__func_8h.html#a4ccb0c4ec0db3c700b6d20b02175f534',1,'vg_draw_element(xpm_row_t *pixmap, uint16_t x, uint16_t y):&#160;vbe.c']]],
  ['vg_5fdraw_5fhline_367',['vg_draw_hline',['../vbe_8c.html#a5e5b25bd525250f61f40b9e9f212d5e6',1,'vbe.c']]],
  ['vg_5fdraw_5frectangle_368',['vg_draw_rectangle',['../vbe_8c.html#a99d2da2559e11200c6b40c469e9977ec',1,'vbe.c']]],
  ['vg_5fdraw_5fsprite_369',['vg_draw_sprite',['../vbe_8c.html#a7aacee3dbbba922b03e8d29d511d6897',1,'vg_draw_sprite(uint8_t *sprite, uint16_t x, uint16_t y, uint16_t width, uint16_t height):&#160;vbe.c'],['../vbe__func_8h.html#a7aacee3dbbba922b03e8d29d511d6897',1,'vg_draw_sprite(uint8_t *sprite, uint16_t x, uint16_t y, uint16_t width, uint16_t height):&#160;vbe.c']]],
  ['vg_5fgenerate_5fpixel_370',['vg_generate_pixel',['../vbe_8c.html#a99cb2ed48beffe1117bab7d4ebc1eb57',1,'vg_generate_pixel(uint16_t x, uint16_t y, uint32_t color):&#160;vbe.c'],['../vbe__func_8h.html#a99cb2ed48beffe1117bab7d4ebc1eb57',1,'vg_generate_pixel(uint16_t x, uint16_t y, uint32_t color):&#160;vbe.c']]],
  ['vg_5finit_371',['vg_init',['../vbe_8c.html#aa6c1ff5024cd4d15e476bce487584daa',1,'vbe.c']]],
  ['vg_5fread_5fpixmap_372',['vg_read_pixmap',['../vbe_8c.html#a0c16850c0cf73b1e331af7d5f189d30a',1,'vg_read_pixmap(xpm_row_t *pixmap, uint16_t *width, uint16_t *height):&#160;vbe.c'],['../vbe__func_8h.html#a0c16850c0cf73b1e331af7d5f189d30a',1,'vg_read_pixmap(xpm_row_t *pixmap, uint16_t *width, uint16_t *height):&#160;vbe.c']]]
];
