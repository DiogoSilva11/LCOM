var modules =
[
    [ "bios", "group__bios.html", "group__bios" ],
    [ "i8042", "group__i8042.html", "group__i8042" ],
    [ "i8254", "group__i8254.html", "group__i8254" ],
    [ "kbd", "group__kbd.html", "group__kbd" ],
    [ "m_i8042", "group__m__i8042.html", "group__m__i8042" ],
    [ "mouse", "group__mouse.html", "group__mouse" ],
    [ "xpm", "group__xpm.html", "group__xpm" ]
];