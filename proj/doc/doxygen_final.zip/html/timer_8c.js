var timer_8c =
[
    [ "timer_display_conf", "timer_8c.html#a140d8f092c0913cabdca949c4a1cc650", null ],
    [ "timer_get_conf", "timer_8c.html#a703c60b40c8c49607d6ecb6fef82d27a", null ],
    [ "timer_int_handler", "timer_8c.html#a91a2072306c68353712a6b771287dc2c", null ],
    [ "timer_set_frequency", "timer_8c.html#af2c04fa8e97ffa748fd3f612886a92a7", null ],
    [ "timer_subscribe_int", "timer_8c.html#ac57a7e1140a7e00ad95ac5488d2a671b", null ],
    [ "timer_unsubscribe_int", "timer_8c.html#afabd21de449be154dd65d5fdb2d8045d", null ],
    [ "hook_id", "timer_8c.html#a96f78a87d064e47d627d222f67a8d012", null ],
    [ "int_counter", "timer_8c.html#a2715a64ed7e692c661ab6b75ac16d278", null ]
];