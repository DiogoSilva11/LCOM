var structRobot =
[
    [ "alive", "structRobot.html#a40baadb1b9c433367118014204714d41", null ],
    [ "x", "structRobot.html#a32c50e8f8352da3601c34c54f32649fa", null ],
    [ "y", "structRobot.html#aa9d4cd428042e1f5dd4723dd383e38d7", null ]
];