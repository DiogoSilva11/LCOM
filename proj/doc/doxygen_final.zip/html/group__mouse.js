var group__mouse =
[
    [ "mouse_cmd", "group__mouse.html#gad22db28d69deb432b9d76d08f1f01be0", null ],
    [ "mouse_delta_x", "group__mouse.html#gacba7d164c0c4ae63c2462a1bd81c4031", null ],
    [ "mouse_delta_y", "group__mouse.html#gab54fa02bfb408896c967359da702bc57", null ],
    [ "mouse_disable", "group__mouse.html#gacd4cec128d1f9c05bd42ea09bfbfb955", null ],
    [ "mouse_disable_data_reporting", "group__mouse.html#ga7e311379d4d64f88873ef8ade5c82a25", null ],
    [ "mouse_enable", "group__mouse.html#ga09fdcdb2e2301e81c45a994fd95cb826", null ],
    [ "mouse_event", "group__mouse.html#gafacd201d8136c7fc6da5c5a3e6e45948", null ],
    [ "mouse_organize_struct", "group__mouse.html#ga28dd30fc3599f0ceb7a5157d01f4aaf4", null ],
    [ "mouse_overflow", "group__mouse.html#gab915f47a154ac1bc1ed356c3532ee3b0", null ],
    [ "mouse_packet_full", "group__mouse.html#ga5be2bd6ecb969207c8ba6bb5760015d3", null ],
    [ "mouse_ret_value", "group__mouse.html#gaf7e66739b215c1ab886db2e4edfda80a", null ],
    [ "mouse_state", "group__mouse.html#ga49c288b00128328e5b98f4be96005f8e", null ],
    [ "mouse_subscribe_int", "group__mouse.html#ga20285aed4b3ef45812cd967532dd09db", null ],
    [ "mouse_unsubscribe_int", "group__mouse.html#ga3ecf823d80520009ae5e0d76ae40a3c3", null ]
];