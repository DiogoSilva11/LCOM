var utils_8c =
[
    [ "util_get_LSB", "utils_8c.html#a81621440b3d65680979425e39aa8c789", null ],
    [ "util_get_MSB", "utils_8c.html#a6a880076cd2ec468834438b6e0c58836", null ],
    [ "util_sys_inb", "utils_8c.html#a79a031a8611f5b2d6afa4158e92b0fb4", null ]
];