var structHero =
[
    [ "alive", "structHero.html#aa638f6d83580dacb46d8e3e9358066b1", null ],
    [ "x", "structHero.html#a51935f2833c54a990f04eca42c6fae8b", null ],
    [ "y", "structHero.html#abb59184fcb4fc16c9e8a4762e764a33b", null ]
];