var structCrosshair =
[
    [ "x", "structCrosshair.html#a5983109ad85f2b9562ce8d5f80ac785a", null ],
    [ "y", "structCrosshair.html#a170b9e354b03ea04340936beef805a24", null ]
];