var annotated_dup =
[
    [ "Bullet", "structBullet.html", "structBullet" ],
    [ "Crosshair", "structCrosshair.html", "structCrosshair" ],
    [ "Fence", "structFence.html", "structFence" ],
    [ "Hero", "structHero.html", "structHero" ],
    [ "Robot", "structRobot.html", "structRobot" ]
];