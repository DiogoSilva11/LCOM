var vbe_8c =
[
    [ "bytes_per_pixel", "vbe_8c.html#aac1597a72e55f391bfb1569d215feaab", null ],
    [ "get_hres", "vbe_8c.html#a96831d611df1b6f4402dec1da8eaaef5", null ],
    [ "get_vres", "vbe_8c.html#adbb976e8111bdebbf31503894844e592", null ],
    [ "map_memory", "vbe_8c.html#af1bf9e7f07f92f3f1561df4630ce33d1", null ],
    [ "vg_clear_screen", "vbe_8c.html#a5d8853f182ab463c0d667a1c802a3713", null ],
    [ "vg_draw_content", "vbe_8c.html#ac305e1409155c669200217cc8a7aefce", null ],
    [ "vg_draw_element", "vbe_8c.html#a4ccb0c4ec0db3c700b6d20b02175f534", null ],
    [ "vg_draw_hline", "vbe_8c.html#a5e5b25bd525250f61f40b9e9f212d5e6", null ],
    [ "vg_draw_rectangle", "vbe_8c.html#a99d2da2559e11200c6b40c469e9977ec", null ],
    [ "vg_draw_sprite", "vbe_8c.html#a7aacee3dbbba922b03e8d29d511d6897", null ],
    [ "vg_generate_pixel", "vbe_8c.html#a99cb2ed48beffe1117bab7d4ebc1eb57", null ],
    [ "vg_init", "vbe_8c.html#aa6c1ff5024cd4d15e476bce487584daa", null ],
    [ "vg_read_pixmap", "vbe_8c.html#a0c16850c0cf73b1e331af7d5f189d30a", null ],
    [ "clrdepth", "vbe_8c.html#a832eacefacc19cebd5f39e42dccc12af", null ],
    [ "hres", "vbe_8c.html#abc3c784566289e1414929d23e32a0c6c", null ],
    [ "video_buffer", "vbe_8c.html#a9dd702e63e63161a33a17df975310705", null ],
    [ "video_mem", "vbe_8c.html#a5077a1a703b40b073dc6b5c1129ab0a1", null ],
    [ "vmi_p", "vbe_8c.html#a26081be7a771e5c611b33f15caaf831e", null ],
    [ "vram_size", "vbe_8c.html#a17b12b87c65aaa04215d9bdb7e9e84dd", null ],
    [ "vres", "vbe_8c.html#a573eca15e5986d6dd7ae53b5dab582e2", null ]
];