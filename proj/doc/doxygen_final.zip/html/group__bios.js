var group__bios =
[
    [ "BIOS_INT", "group__bios.html#ga0cc2e12b7b3a6b69c7ec7cf4892a463e", null ],
    [ "VBE_FUNC_CALL", "group__bios.html#ga919813aaa650de9b3434b9bf1970ed5c", null ],
    [ "VBE_FUNC_FAIL", "group__bios.html#gac0799fa6d233f113fb31ece5c47dc5c8", null ],
    [ "VBE_FUNC_HW", "group__bios.html#ga48dc977c617273138ddbd1d561203626", null ],
    [ "VBE_FUNC_INV", "group__bios.html#ga73c2351a1134cbc27d69fcff7235f163", null ],
    [ "VBE_FUNC_OK", "group__bios.html#gacf43e5c9535103ab7cdb9ec58f24139b", null ],
    [ "VBE_FUNC_SUP", "group__bios.html#ga30e52e7aff947a78b13091e2563d437f", null ],
    [ "VBE_LINEAR_BUF", "group__bios.html#ga4f973c2c166ca409c8dc18e0810de106", null ],
    [ "VBE_MODE_INFO", "group__bios.html#ga2ecbf8f92f9322fedec91461747c4843", null ],
    [ "VBE_SET_MODE", "group__bios.html#ga02477c4996ff058aee590b54f2146eb5", null ]
];