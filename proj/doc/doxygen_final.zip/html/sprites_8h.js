var sprites_8h =
[
    [ "bullet_sprite", "group__xpm.html#gaedb14372b536a8f763851c28d634a388", null ],
    [ "crosshair_sprite", "group__xpm.html#ga5a8bab6f75c6330bc3451f24514c552d", null ],
    [ "dead_robot_sprite", "group__xpm.html#ga0394512e76820d88136bd498d8e1fe95", null ],
    [ "fence_sprite", "group__xpm.html#gac3bca7ac2010a0513d4b3ea7f8cc54a2", null ],
    [ "hero_sprite", "group__xpm.html#gac1bb08ae15640fcdf0b3b86b82de3eaf", null ],
    [ "robot_sprite", "group__xpm.html#gad7444f5b4e7d8c23e2b95be18f28fde4", null ]
];