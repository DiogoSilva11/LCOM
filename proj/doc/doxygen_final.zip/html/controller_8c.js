var controller_8c =
[
    [ "init", "controller_8c.html#a6611da0eaaaa020ce5748914abff7828", null ],
    [ "leave", "controller_8c.html#a5660953c43c447e3e57c44f7eacf432e", null ],
    [ "kbd_irq_set", "controller_8c.html#a11e3e597821ff4545170bd90df91c9ab", null ],
    [ "mouse_irq_set", "controller_8c.html#a9492cf9c0db01b22708557dfed5fef2b", null ],
    [ "timer_irq_set", "controller_8c.html#a303254e04e052ac3fd8c833156e26093", null ]
];