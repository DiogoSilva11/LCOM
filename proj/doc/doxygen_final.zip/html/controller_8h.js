var controller_8h =
[
    [ "init", "controller_8h.html#a6611da0eaaaa020ce5748914abff7828", null ],
    [ "leave", "controller_8h.html#a5660953c43c447e3e57c44f7eacf432e", null ]
];