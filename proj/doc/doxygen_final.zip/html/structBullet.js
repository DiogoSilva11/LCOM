var structBullet =
[
    [ "hit", "structBullet.html#aeb639dd2a8df6556c6d5b91a8b01bd25", null ],
    [ "x", "structBullet.html#add8da3ee8a3265a38ebbfe8a254ebb19", null ],
    [ "xDest", "structBullet.html#a3a8e3fc9966674ad3f0b7d8a1de8e770", null ],
    [ "y", "structBullet.html#a524e0ee515b1418341cdd8f8dffce1ee", null ],
    [ "yDest", "structBullet.html#a8d849365a38788ba8f366b5716155c5d", null ]
];